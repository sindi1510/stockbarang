# StockGu
StockGu (Stock Gudang) adalah aplikasi web simple untuk manajemen inventory. terdapat beberapa menu yaitu menu barang untuk melakukan crud barang, menu supplier, dan menu mutasi barang
